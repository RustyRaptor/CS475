# Lab 1 CS 475
Ziad Arafat
Feb 2 2021

## How to compile
Run this command in a terminal
```
make
```

## Usage

***There are 3 test case files in the folder and they are run automatically in sequence***

Run this command in a terminal.

```
make run
```
- The program will automatically run on nodes.txt, nodes2.txt, and nodes3.txt