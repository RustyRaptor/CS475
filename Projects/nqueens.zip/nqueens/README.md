# Lab 1 CS 475
Ziad Arafat
Feb 2 2021

## How to compile
Run this command in a terminal
```
make
```

## Usage

Run this command in a terminal.

```
make run
```
- The program will then ask you to enter the value of N
- After you enter the integer and press enter it will either print a sequence of numbers as the solution or it will inform you that there is no solution.